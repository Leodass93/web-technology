<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


$servername = "localhost";
$username = "root";
$password = "";
$database = "employee_db";


$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error) {
    die(" Connection failed: " . $conn->connect_error);
}


$full_name = $_POST['full_name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$department = $_POST['department'];
$hire_date = $_POST['hire_date'];


$sql = "INSERT INTO employees (full_name, email, phone, department, hire_date)
        VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $full_name, $email, $phone, $department, $hire_date);

if ($stmt->execute()) {
    echo "<h2>Employee record saved successfully.</h2> ";
    echo "<a href='index.html'> Go Back</a>";
} else {
    echo " Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
