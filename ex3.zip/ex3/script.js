const questions = [
    {
        question: "What is the capital of France?",
        answers: ["Paris", "London", "Berlin", "Rome"],
        correct: 0
    },
    {
        question: "Which planet is known as the Red Planet?",
        answers: ["Earth", "Mars", "Jupiter", "Venus"],
        correct: 1
    },
    {
        question: "Who wrote 'Romeo and Juliet'?",
        answers: ["Shakespeare", "Dickens", "Tolkien", "Rowling"],
        correct: 0
    },
    {
        question: "What is 5 + 7?",
        answers: ["12", "10", "13", "11"],
        correct: 0
    },
    {
        question: "What gas do plants absorb?",
        answers: ["Oxygen", "Hydrogen", "Carbon Dioxide", "Nitrogen"],
        correct: 2
    },
    {
        question: "Who painted the Mona Lisa?",
        answers: ["Michelangelo", "Picasso", "Da Vinci", "Rembrandt"],
        correct: 2
    },
    {
        question: "What is the boiling point of water?",
        answers: ["90°C", "100°C", "80°C", "110°C"],
        correct: 1
    },
    {
        question: "Which is the largest ocean?",
        answers: ["Atlantic", "Pacific", "Indian", "Arctic"],
        correct: 1
    },
    {
        question: "Which language has the most speakers?",
        answers: ["English", "Mandarin", "Spanish", "Hindi"],
        correct: 1
    },
    {
        question: "How many continents are there?",
        answers: ["5", "6", "7", "8"],
        correct: 2
    },
    {
        question: "What is H2O?",
        answers: ["Oxygen", "Hydrogen", "Water", "Salt"],
        correct: 2
    },
    {
        question: "Who discovered gravity?",
        answers: ["Einstein", "Galileo", "Newton", "Tesla"],
        correct: 2
    },
    {
        question: "Which is the fastest land animal?",
        answers: ["Tiger", "Cheetah", "Lion", "Panther"],
        correct: 1
    },
    {
        question: "What color is the sun?",
        answers: ["Yellow", "White", "Orange", "Red"],
        correct: 1
    },
    {
        question: "Which country invented pizza?",
        answers: ["Greece", "France", "Italy", "Spain"],
        correct: 2
    },
    {
        question: "How many bones in the human body?",
        answers: ["206", "205", "201", "210"],
        correct: 0
    },
    {
        question: "What is the largest mammal?",
        answers: ["Elephant", "Blue Whale", "Giraffe", "Hippo"],
        correct: 1
    },
    {
        question: "Which metal is liquid at room temperature?",
        answers: ["Iron", "Mercury", "Copper", "Zinc"],
        correct: 1
    },
    {
        question: "Who was the first man on the moon?",
        answers: ["Buzz Aldrin", "Yuri Gagarin", "Neil Armstrong", "John Glenn"],
        correct: 2
    },
    {
        question: "What is the square root of 144?",
        answers: ["10", "11", "12", "13"],
        correct: 2
    }
];

let currentQuestionIndex = 0;
let score = 0;

const questionEl = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const resultContainer = document.getElementById("result-container");
const questionContainer = document.getElementById("question-container");
const scoreEl = document.getElementById("score");

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerText = "Next";
    showQuestion();
}

function showQuestion() {
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    

    const questionNumberEl = document.getElementById("question-number");
    questionNumberEl.innerText = `Question ${currentQuestionIndex + 1} of ${questions.length}`;
    
    questionEl.innerText = currentQuestion.question;

    currentQuestion.answers.forEach((answer, index) => {
        const btn = document.createElement("button");
        btn.innerText = answer;
        btn.classList.add("btn");
        btn.addEventListener("click", () => selectAnswer(index));
        answerButtons.appendChild(btn);
    });
}

function resetState() {
    nextButton.style.display = "none";
    answerButtons.innerHTML = "";
}

function selectAnswer(index) {
    const correct = questions[currentQuestionIndex].correct;
    const buttons = answerButtons.children;

    for (let i = 0; i < buttons.length; i++) {
        buttons[i].disabled = true;
        if (i === correct) {
            buttons[i].style.backgroundColor = "green";
        } else if (i === index) {
            buttons[i].style.backgroundColor = "red";
        }
    }

    if (index === correct) {
        score++;
    }

    nextButton.style.display = "block";
}

nextButton.addEventListener("click", () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        showScore();
    }
});

function showScore() {
    questionContainer.classList.add("hide");
    resultContainer.classList.remove("hide");
    scoreEl.innerText = score;
}

startQuiz();
