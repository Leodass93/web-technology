document.addEventListener('DOMContentLoaded', function() {
    const actions = document.querySelector('.actions');
    const ans = document.querySelector('.ans');
    let expression = '';
    let isInverse = false;

    actions.addEventListener('click', (e) => {
        const value = e.target.dataset['value'];

        if (value !== undefined) {
            if (value === 'ce') {
                expression = '';
                ans.value = '0';
            } else if (value === 'inv') {
                isInverse = !isInverse;
                e.target.classList.toggle('active');
            } else if (value === '=') {
                try {
                    const answer = eval(expression);
                    expression = formatNumber(answer.toString());
                    ans.value = expression;
                } catch (error) {
                    ans.value = 'Error';
                    expression = '';
                }
            } else if (['sin', 'cos', 'tan', 'log', 'ln', 'radic', 'x^2'].includes(value)) {
                try {
                    let num = parseFloat(expression);
                    if (isNaN(num)) num = 0;

                    let result;
                    switch (value) {
                        case 'sin':
                            result = isInverse ? Math.asin(num) : Math.sin(num);
                            break;
                        case 'cos':
                            result = isInverse ? Math.acos(num) : Math.cos(num);
                            break;
                        case 'tan':
                            result = isInverse ? Math.atan(num) : Math.tan(num);
                            break;
                        case 'log':
                            result = Math.log10(num);
                            break;
                        case 'ln':
                            result = Math.log(num);
                            break;
                        case 'radic':
                            result = Math.sqrt(num);
                            break;
                        case 'x^2':
                            result = num * num;
                            break;
                    }

                    expression = formatNumber(result.toString());
                    ans.value = expression;
                } catch (error) {
                    ans.value = 'Error';
                    expression = '';
                }
            } else if (value === 'exp') {
                expression += 'e+';
                ans.value = expression;
            } else {
                if (expression === '0' && !isNaN(value)) {
                    expression = value;
                } else {
                    expression += value;
                }
                ans.value = expression;
            }
        }
    });

    function formatNumber(numStr) {
        const num = parseFloat(numStr);
        if (isNaN(num)) return numStr;
        if (Number.isInteger(num)) return num.toString();
        const rounded = Math.round(num * 1e10) / 1e10;
        return rounded.toString();
    }
});
